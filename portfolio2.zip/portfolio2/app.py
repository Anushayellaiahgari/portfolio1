from flask import Flask,render_template

app=Flask(__name__)
 
@app.route('/',methods=['GET']) #get method
def ind():
    return render_template('index.html')

@app.route('/blog',methods=['GET'])
def blog_single():
    return render_template('blog_single.html')

@app.route('/port',methods=['GET'])
def portfolio_details():
    return render_template('portfolio_details.html')

if __name__=='__main__':
    app.run(debug=True)